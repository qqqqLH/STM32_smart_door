#include "lpcreg.h"
#include "main.h"
#include "mfrc522.h"

unsigned char code data1[16] = {0x12,0x34,0x56,0x78,0xED,0xCB,0xA9,0x87,0x12,0x34,0x56,0x78,0x01,0xFE,0x01,0xFE};
//M1����ĳһ��дΪ���¸�ʽ����ÿ�ΪǮ�����ɽ��տۿ�ͳ�ֵ����
//4�ֽڽ����ֽ���ǰ����4�ֽڽ��ȡ����4�ֽڽ�1�ֽڿ��ַ��1�ֽڿ��ַȡ����1�ֽڿ��ַ��1�ֽڿ��ַȡ�� 
unsigned char code data2[4]  = {0x12,0,0,0};
unsigned char code DefaultKey[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}; 


unsigned char g_ucTempbuf[20];                        

void main( )
{    
     unsigned char status;
     InitializeSystem( );
     PcdReset();
     PcdAntennaOff(); //�ر�����
     PcdAntennaOn();  //��������
     while ( 1 )
     {   
         status = PcdRequest(PICC_REQALL, g_ucTempbuf);       #define PICC_REQIDL 0x26    //Ѱ��������δ��������״̬
////////////////////////////////////////////////////////////////////////////////
         if (status != MI_OK)
         { 
              LED_GREEN = 1;
	      continue;
         }
/////////////////////////////////////////////////////////////////////
         LED_GREEN = 0;
         status = PcdAnticoll(g_ucTempbuf);
//////////////////////////////////////////////////////////////////////
         if (status != MI_OK)
         { 
             continue;    
         }
/////////////////////////////////////////////////////////////////////
         status = PcdSelect(g_ucTempbuf);
         if (status != MI_OK)
         {    
            continue;    
         }
////////////////////////////////////////////////////////////////////////////         
         status = PcdAuthState(PICC_AUTHENT1A, 1, DefaultKey, g_ucTempbuf);
         if (status != MI_OK)
         {    
             continue;    
         }
/////////////////////////////////////////////////////////////////////////////         
         status = PcdWrite(1, data1);
         if (status != MI_OK)
         {    
            continue;    
         }
/////////////////////////////////////////////////////////////////////////////////         
         status = PcdValue(PICC_DECREMENT,1,data2);
         if (status != MI_OK)
         {    
           continue;    
         }
/////////////////////////////////////////////////////////////////////////////////         
         status = PcdBakValue(1, 2);
         if (status != MI_OK)
         {    
             continue;    
         }
/////////////////////////////////////////////////////////////////////////////         
         status = PcdRead(2, g_ucTempbuf);
         if (status != MI_OK)
         {    
            continue;   
         }
          PcdHalt();   //���Ƭ��������״̬
    }
}


/////////////////////////////////////////////////////////////////////
//ϵͳ��ʼ��
/////////////////////////////////////////////////////////////////////
void InitializeSystem()
{
    P0M1 = 0x0; P0M2 = 0x0;
    P1M1 = 0x0;	P1M2 = 0x0;                      
    P3M1 = 0x0; P3M2 = 0xFF; 
    P0 = 0xFF; P1 = 0xFF; P3 = 0xFF;
}
/////////////////////////////////////////////////////////////////////
//��    �ܣ���λRC522
//��    ��: �ɹ�����MI_OK
/////////////////////////////////////////////////////////////////////
char PcdReset(void)
{
    MF522_RST=1;
    _nop_();
    MF522_RST=0;
    _nop_();
    MF522_RST=1;
     _nop_();
    WriteRawRC(CommandReg,PCD_RESETPHASE);
    _nop_();
    
    WriteRawRC(ModeReg,0x3D);            //��Mifare��ͨѶ��CRC��ʼֵ0x6363
    WriteRawRC(TReloadRegL,30);           
    WriteRawRC(TReloadRegH,0);
    WriteRawRC(TModeReg,0x8D);
    WriteRawRC(TPrescalerReg,0x3E);
   
    return MI_OK;
}
/////////////////////////////////////////////////////////////////////
//��    �ܣ�дRC632�Ĵ���
//����˵����Address[IN]:�Ĵ�����ַ
//          value[IN]:д���ֵ
/////////////////////////////////////////////////////////////////////
void WriteRawRC(unsigned char Address, unsigned char value)
{  
    unsigned char i, ucAddr;

    MF522_SCK = 0;
    MF522_NSS = 0;
    ucAddr = ((Address<<1)&0x7E);

    for(i=8;i>0;i--)
    {
        MF522_SI = ((ucAddr&0x80)==0x80);
        MF522_SCK = 1;
        ucAddr <<= 1;
        MF522_SCK = 0;
    }

    for(i=8;i>0;i--)
    {
        MF522_SI = ((value&0x80)==0x80);
        MF522_SCK = 1;
        value <<= 1;
        MF522_SCK = 0;
    }
    MF522_NSS = 1;
    MF522_SCK = 1;
}
/////////////////////////////////////////////////////////////////////
//��    �ܣ���RC632�Ĵ���
//����˵����Address[IN]:�Ĵ�����ַ
//��    �أ�������ֵ
/////////////////////////////////////////////////////////////////////
unsigned char ReadRawRC(unsigned char Address)
{
     unsigned char i, ucAddr;
     unsigned char ucResult=0;

     MF522_SCK = 0;
     MF522_NSS = 0;
     ucAddr = ((Address<<1)&0x7E)|0x80;

     for(i=8;i>0;i--)
     {
         MF522_SI = ((ucAddr&0x80)==0x80);
         MF522_SCK = 1;
         ucAddr <<= 1;
         MF522_SCK = 0;
     }

     for(i=8;i>0;i--)
     {
         MF522_SCK = 1;
         ucResult <<= 1;
         ucResult|=(bit)MF522_SO;
         MF522_SCK = 0;
     }

     MF522_NSS = 1;
     MF522_SCK = 1;
     return ucResult;
}
   
  

